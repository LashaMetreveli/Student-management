# Java_Projects

   Calculator

        javafx



   ![image](https://github.com/lasha1metreveli/Personal-Projects/blob/master/images/calculator.png?raw=true)
   
   
   Database manager 
   
         javafx, sqlite
         
   Add user information, Clear Fields and Load Table options
   
   ![image](https://github.com/lasha1metreveli/Personal-Projects/blob/master/images/admin%20board.PNG)
   
   Login screen 
   
   ![image](https://github.com/lasha1metreveli/Personal-Projects/blob/master/images/login.PNG)
   

   
